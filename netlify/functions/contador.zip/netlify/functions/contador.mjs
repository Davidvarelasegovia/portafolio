
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/lib/db.js
import { MongoClient } from "mongodb";
var globalForMongo = globalThis;
var getDb = async () => {
  const uri = process.env.MONGODB_URI;
  if (!uri) {
    throw new Error("Falta la variable de entorno MONGODB_URI");
  }
  let client = globalForMongo.__mongoClient;
  if (!client) {
    client = new MongoClient(uri, {
      serverSelectionTimeoutMS: 8e3
    });
    await client.connect();
    globalForMongo.__mongoClient = client;
    console.log("\u2705 Conectado a MongoDB Atlas");
  }
  return client.db(process.env.MONGODB_DB || "portafolio");
};
var visitasCollection = async () => {
  const db = await getDb();
  return db.collection("visitas");
};

// netlify/functions/contador.js
var corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type"
};
var contador_default = async (request) => {
  if (request.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: corsHeaders });
  }
  try {
    const col = await visitasCollection();
    const total = await col.countDocuments({});
    const tz = process.env.TZ || "America/Santiago";
    const ahora = /* @__PURE__ */ new Date();
    const inicioDia = new Date(
      ahora.toLocaleString("en-US", { timeZone: tz })
    );
    const hoy = await col.countDocuments({ fecha: { $gte: inicioDia } });
    return new Response(
      JSON.stringify({ total, hoy }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("\u274C Error obteniendo contador:", error);
    return new Response(
      JSON.stringify({ total: 0, hoy: 0 }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
};
export {
  contador_default as default
};
