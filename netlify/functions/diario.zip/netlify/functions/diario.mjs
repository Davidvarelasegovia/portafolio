
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/lib/db.js
import { MongoClient } from "mongodb";
var globalForMongo = globalThis;
var getDb = async () => {
  const uri = process.env.MONGODB_URI;
  if (!uri) {
    throw new Error("Falta la variable de entorno MONGODB_URI");
  }
  let client = globalForMongo.__mongoClient;
  if (!client) {
    client = new MongoClient(uri, {
      serverSelectionTimeoutMS: 8e3
    });
    await client.connect();
    globalForMongo.__mongoClient = client;
    console.log("\u2705 Conectado a MongoDB Atlas");
  }
  return client.db(process.env.MONGODB_DB || "portafolio");
};
var visitasCollection = async () => {
  const db = await getDb();
  return db.collection("visitas");
};

// netlify/lib/mailer.js
import nodemailer from "nodemailer";
var DESTINO_POR_DEFECTO = "davidvareladavid@gmail.com";
var getTransport = () => {
  const user = process.env.EMAIL_USER;
  const pass = process.env.EMAIL_PASS;
  if (!user || !pass) {
    throw new Error(
      "Faltan EMAIL_USER o EMAIL_PASS en las variables de entorno"
    );
  }
  return nodemailer.createTransport({
    service: "gmail",
    auth: { user, pass }
  });
};
var fila = (etiqueta, valor) => `
  <tr>
    <td style="padding:8px 12px;border-bottom:1px solid #e5e5f5;color:#666;font-size:13px;white-space:nowrap;">
      ${etiqueta}
    </td>
    <td style="padding:8px 12px;border-bottom:1px solid #e5e5f5;color:#1a1a2e;font-size:14px;font-weight:500;">
      ${valor ?? "\u2014"}
    </td>
  </tr>`;
var escaparHtml = (texto) => String(texto ?? "").replace(
  /[&<>"']/g,
  (c) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  })[c]
);
var escaparUrl = (url) => {
  const limpio = String(url ?? "").trim();
  if (!limpio) return "No presente";
  return escaparHtml(limpio);
};
var formatearFecha = (fecha) => new Date(fecha).toLocaleString("es-CL", {
  timeZone: process.env.TZ || "America/Santiago",
  dateStyle: "full",
  timeStyle: "medium"
});
var enviarResumenDiario = async ({ visitas, totalDia, totalAbsoluto, sitio }) => {
  const transporte = getTransport();
  const destino = process.env.EMAIL_DESTINO || DESTINO_POR_DEFECTO;
  const fechaTitulo = formatearFecha(/* @__PURE__ */ new Date());
  const asunto = `\u{1F4CA} Resumen de visitas \u2014 ${fechaTitulo}`;
  const filasVisitas = visitas.map(
    (v, i) => `
      <tr>
        <td style="padding:10px 12px;border-bottom:1px solid #e5e5f5;font-size:13px;color:#3931e1;font-weight:600;">
          ${i + 1}
        </td>
        <td style="padding:10px 12px;border-bottom:1px solid #e5e5f5;font-size:13px;color:#1a1a2e;">
          ${escaparHtml(
      new Date(v.fecha).toLocaleTimeString("es-CL", {
        timeZone: process.env.TZ || "America/Santiago",
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit"
      })
    )}
        </td>
        <td style="padding:10px 12px;border-bottom:1px solid #e5e5f5;font-size:13px;color:#1a1a2e;">
          ${escaparHtml(
      [v.ciudad, v.region].filter(Boolean).join(", ") || "Desconocida"
    )}<br>
          <span style="color:#888;">${escaparHtml(v.pais)}</span>
        </td>
        <td style="padding:10px 12px;border-bottom:1px solid #e5e5f5;font-size:13px;color:#4a4b6d;">
          ${escaparHtml(v.pagina || "/")}
        </td>
        <td style="padding:10px 12px;border-bottom:1px solid #e5e5f5;font-size:13px;color:#4a4b6d;">
          ${escaparHtml(v.navegador)} \xB7 ${escaparHtml(v.sistema)}<br>
          <span style="color:#888;">${escaparHtml(v.dispositivo)}</span>
        </td>
        <td style="padding:10px 12px;border-bottom:1px solid #e5e5f5;font-size:12px;color:#999;font-family:monospace;">
          ${escaparHtml(v.ip)}
        </td>
      </tr>`
  ).join("");
  const html = `
  <!doctype html>
  <html lang="es">
    <body style="margin:0;padding:24px;background:#f3f0ff;font-family:'Segoe UI',Roboto,Helvetica,Arial,sans-serif;">
      <div style="max-width:900px;margin:0 auto;background:#fff;border-radius:14px;overflow:hidden;box-shadow:0 4px 20px rgba(0,0,0,.08);">

        <div style="background:linear-gradient(135deg,#3931e1,#5b52f0);padding:28px 32px;">
          <h1 style="margin:0;color:#fff;font-size:22px;">Resumen diario de visitas</h1>
          <p style="margin:6px 0 0;color:#dcd9ff;font-size:14px;">
            ${escaparHtml(fechaTitulo)}
          </p>
        </div>

        <div style="padding:28px 32px;">
          <table style="width:100%;border-collapse:separate;border-spacing:10px 0;margin-bottom:28px;">
            <tr>
              <td style="background:#f7f7fd;border-radius:10px;padding:18px;text-align:center;">
                <div style="font-size:30px;font-weight:bold;color:#3931e1;">${totalDia}</div>
                <div style="font-size:13px;color:#666;margin-top:4px;">Visitas hoy</div>
              </td>
              <td style="background:#f7f7fd;border-radius:10px;padding:18px;text-align:center;">
                <div style="font-size:30px;font-weight:bold;color:#232155;">${totalAbsoluto}</div>
                <div style="font-size:13px;color:#666;margin-top:4px;">Total hist\xF3rico</div>
              </td>
              <td style="background:#f7f7fd;border-radius:10px;padding:18px;text-align:center;">
                <div style="font-size:30px;font-weight:bold;color:#25D366;">
                  ${new Set(visitas.map((v) => v.pais)).size}
                </div>
                <div style="font-size:13px;color:#666;margin-top:4px;">Pa\xEDses distintos hoy</div>
              </td>
            </tr>
          </table>

          ${visitas.length === 0 ? `<div style="background:#f7f7fd;border-radius:10px;padding:26px;text-align:center;color:#888;">
                   No se registraron visitas hoy.
                 </div>` : `
          <h2 style="font-size:17px;color:#232155;margin:0 0 12px;">
            Detalle de las visitas
          </h2>
          <table style="width:100%;border-collapse:collapse;">
            <thead>
              <tr style="background:#f7f7fd;">
                <th style="padding:10px 12px;text-align:left;font-size:12px;color:#3931e1;text-transform:uppercase;letter-spacing:.5px;">#</th>
                <th style="padding:10px 12px;text-align:left;font-size:12px;color:#3931e1;text-transform:uppercase;letter-spacing:.5px;">Hora</th>
                <th style="padding:10px 12px;text-align:left;font-size:12px;color:#3931e1;text-transform:uppercase;letter-spacing:.5px;">Lugar</th>
                <th style="padding:10px 12px;text-align:left;font-size:12px;color:#3931e1;text-transform:uppercase;letter-spacing:.5px;">P\xE1gina</th>
                <th style="padding:10px 12px;text-align:left;font-size:12px;color:#3931e1;text-transform:uppercase;letter-spacing:.5px;">Navegador</th>
                <th style="padding:10px 12px;text-align:left;font-size:12px;color:#3931e1;text-transform:uppercase;letter-spacing:.5px;">IP</th>
              </tr>
            </thead>
            <tbody>${filasVisitas}</tbody>
          </table>`}

          <div style="margin-top:28px;padding-top:20px;border-top:1px solid #eee;">
            <table style="width:100%;border-collapse:collapse;">
              ${fila("Sitio web visto", escaparUrl(sitio))}
              ${fila("Enviado autom\xE1ticamente", "Vercel Cron")}
              ${fila("Destinatario", escaparHtml(destino))}
            </table>
          </div>
        </div>
      </div>
    </body>
  </html>`;
  const info = await transporte.sendMail({
    from: `"Portafolio David Varela" <${process.env.EMAIL_USER}>`,
    to: destino,
    subject: asunto,
    html
  });
  console.log(`\u{1F4E7} Resumen enviado a ${destino} \u2014 ${info.messageId}`);
  return info;
};

// netlify/functions/diario.js
var corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type"
};
var diario_default = async (request) => {
  if (request.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: corsHeaders });
  }
  const secreto = process.env.CRON_SECRET;
  if (!secreto) {
    return new Response(
      JSON.stringify({ error: "CRON_SECRET no est\xE1 configurado" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
  const recibido = request.headers.get("x-cron-secret") || new URL(request.url).searchParams.get("secret");
  if (recibido !== secreto) {
    return new Response(
      JSON.stringify({ error: "No autorizado" }),
      { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
  try {
    const col = await visitasCollection();
    const db = col.db;
    const registros = db.collection("envios");
    const tz = process.env.TZ || "America/Santiago";
    const ahora = /* @__PURE__ */ new Date();
    const inicioDia = new Date(ahora.toLocaleString("en-US", { timeZone: tz }));
    const finDia = new Date(inicioDia);
    finDia.setDate(finDia.getDate() + 1);
    const visitas = await col.find({ fecha: { $gte: inicioDia, $lt: finDia } }).sort({ fecha: 1 }).toArray();
    const totalAbsoluto = await col.countDocuments({});
    const totalDia = visitas.length;
    const clave = inicioDia.toISOString().slice(0, 10);
    const yaEnviado = await registros.findOne({ _id: clave });
    if (yaEnviado) {
      console.log(`\u23ED\uFE0F  Ya se envi\xF3 el resumen del ${clave}. Omitido.`);
      return new Response(
        JSON.stringify({ ok: true, omitido: true, fecha: clave }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }
    const sitio = process.env.SITE_URL || request.headers.get("origin") || "tu-portafolio";
    await enviarResumenDiario({
      visitas,
      totalDia,
      totalAbsoluto,
      sitio
    });
    await registros.insertOne({
      _id: clave,
      fecha: /* @__PURE__ */ new Date(),
      totalDia,
      totalAbsoluto,
      enviado: true
    });
    return new Response(
      JSON.stringify({ ok: true, enviadas: totalDia, totalAbsoluto, fecha: clave }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("\u274C Error enviando resumen diario:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
};
export {
  diario_default as default
};
