
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/lib/db.js
import { MongoClient } from "mongodb";
var globalForMongo = globalThis;
var getDb = async () => {
  const uri = process.env.MONGODB_URI;
  if (!uri) {
    throw new Error("Falta la variable de entorno MONGODB_URI");
  }
  let client = globalForMongo.__mongoClient;
  if (!client) {
    client = new MongoClient(uri, {
      serverSelectionTimeoutMS: 8e3
    });
    await client.connect();
    globalForMongo.__mongoClient = client;
    console.log("\u2705 Conectado a MongoDB Atlas");
  }
  return client.db(process.env.MONGODB_DB || "portafolio");
};
var visitasCollection = async () => {
  const db = await getDb();
  return db.collection("visitas");
};

// netlify/lib/geo.js
var PRIVATE_IPS = [
  "127.0.0.1",
  "::1",
  "localhost",
  "0.0.0.0",
  "::"
];
var esIpPrivada = (ip) => {
  if (!ip) return true;
  const limpia = String(ip).trim().toLowerCase();
  if (PRIVATE_IPS.includes(limpia)) return true;
  return limpia.startsWith("10.") || limpia.startsWith("192.168.") || limpia.startsWith("172.16.") || limpia.startsWith("172.17.") || limpia.startsWith("172.18.") || limpia.startsWith("172.19.") || limpia.startsWith("172.2") || limpia.startsWith("172.30.") || limpia.startsWith("172.31.") || limpia.startsWith("169.254.") || limpia.startsWith("fc") || limpia.startsWith("fd") || limpia.startsWith("fe80");
};
var esIpValida = (ip) => {
  const limpia = String(ip ?? "").trim();
  if (limpia.includes(".")) {
    const partes = limpia.split(".");
    return partes.length === 4 && partes.every((o) => /^\d{1,3}$/.test(o) && Number(o) <= 255);
  }
  if (limpia.includes(":")) {
    return /^[0-9a-f:]+$/i.test(limpia) && limpia.split(":").length >= 3;
  }
  return false;
};
var desconocida = () => ({
  ciudad: "No disponible",
  region: "",
  pais: "No disponible",
  latitud: null,
  longitud: null,
  zonaHoraria: ""
});
var obtenerIp = (req) => {
  const forwarded = req.headers["x-forwarded-for"];
  if (forwarded) {
    return forwarded.split(",")[0].trim();
  }
  return req.headers["x-real-ip"] || req.headers["cf-connecting-ip"] || req.socket?.remoteAddress || "desconocida";
};
var geolocalizar = async (ip) => {
  if (esIpPrivada(ip) || !esIpValida(ip)) {
    return esIpPrivada(ip) ? {
      ciudad: "Local / Privada",
      region: "",
      pais: "Red local",
      latitud: null,
      longitud: null,
      zonaHoraria: ""
    } : desconocida();
  }
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 5e3);
    const res = await fetch(`https://ipwho.is/${ip}`, {
      signal: controller.signal
    });
    clearTimeout(timeout);
    if (!res.ok) throw new Error(`ipwho.is respondi\xF3 ${res.status}`);
    const data = await res.json();
    if (data.success === false) {
      return desconocida();
    }
    return {
      ciudad: data.city || "Desconocida",
      region: data.region || "",
      pais: data.country || "Desconocido",
      latitud: data.latitude ?? null,
      longitud: data.longitude ?? null,
      zonaHoraria: data.timezone?.id || ""
    };
  } catch (error) {
    console.warn("\u26A0\uFE0F Geolocalizaci\xF3n fall\xF3:", error.message);
    return desconocida();
  }
};
var parseUserAgent = (ua = "") => {
  const esMovil = /Mobile|Android|iPhone|iPad|iPod/i.test(ua);
  const esTablet = /iPad|Tablet|PlayBook|Silk/i.test(ua);
  let navegador = "Desconocido";
  if (/Edg\//i.test(ua)) navegador = "Edge";
  else if (/OPR\//i.test(ua)) navegador = "Opera";
  else if (/Firefox\//i.test(ua)) navegador = "Firefox";
  else if (/Chrome\//i.test(ua)) navegador = "Chrome";
  else if (/Safari\//i.test(ua)) navegador = "Safari";
  let sistema = "Desconocido";
  if (/Windows NT 10/i.test(ua)) sistema = "Windows 10/11";
  else if (/Windows/i.test(ua)) sistema = "Windows";
  else if (/iPhone|iPad|iPod/i.test(ua)) sistema = "iOS";
  else if (/Android/i.test(ua)) sistema = "Android";
  else if (/Mac OS X/i.test(ua)) sistema = "macOS";
  else if (/Linux/i.test(ua)) sistema = "Linux";
  let dispositivo = "Escritorio";
  if (esMovil && !esTablet) dispositivo = "M\xF3vil";
  else if (esTablet) dispositivo = "Tablet";
  return { navegador, sistema, dispositivo };
};

// netlify/functions/visita.js
var corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type"
};
var visita_default = async (request) => {
  if (request.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: corsHeaders });
  }
  if (request.method !== "POST") {
    return new Response(
      JSON.stringify({ error: "M\xE9todo no permitido. Usa POST." }),
      { status: 405, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
  try {
    const body = await request.json().catch(() => ({}));
    const ip = obtenerIp(request);
    const userAgent = request.headers.get("user-agent") || "";
    const { navegador, sistema, dispositivo } = parseUserAgent(userAgent);
    const geo = await geolocalizar(ip);
    const visita = {
      fecha: /* @__PURE__ */ new Date(),
      ip,
      ...geo,
      navegador,
      sistema,
      dispositivo,
      pagina: body.pagina || "/",
      referrer: request.headers.get("referer") || "",
      idioma: request.headers.get("accept-language") || "",
      userAgent
    };
    const col = await visitasCollection();
    await col.insertOne(visita);
    const totalAbsoluto = await col.countDocuments({});
    console.log(
      `\u{1F4E5} Visita registrada: ${visita.ciudad}, ${visita.pais} \u2014 Total: ${totalAbsoluto}`
    );
    return new Response(
      JSON.stringify({ ok: true, total: totalAbsoluto }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("\u274C Error registrando visita:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
};
export {
  visita_default as default
};
